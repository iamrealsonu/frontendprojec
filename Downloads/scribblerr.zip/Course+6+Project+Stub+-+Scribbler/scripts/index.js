





function allPost(){
    
 window.location.href ="postslist.html";

}

